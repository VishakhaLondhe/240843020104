package com.knowitdb.GiftedMoments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftedMomentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftedMomentsApplication.class, args);
	}

}
