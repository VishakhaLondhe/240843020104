package com.knowitdb.GiftedMoments.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.knowitdb.GiftedMoments.entities.User;
import com.knowitdb.GiftedMoments.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    //A method to handle user login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User user) {
        User loggedInUser = userService.login(user.getEmail(), user.getPassword());
        
        if (loggedInUser != null) {
           
            String roleName = loggedInUser.getRole().getRolename(); 
            return ResponseEntity.ok(roleName); 
        } else {
            return ResponseEntity.badRequest().body("Invalid email or password");
        }
    }
    
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        try {
            // Calling the service layer to save the user
            userService.createUser(user);
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            
            return ResponseEntity.badRequest().body("Registration failed: " + e.getMessage());
        }
    }
  
}

