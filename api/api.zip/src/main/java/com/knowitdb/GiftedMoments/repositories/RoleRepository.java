package com.knowitdb.GiftedMoments.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.knowitdb.GiftedMoments.entities.Role;

public interface RoleRepository  extends JpaRepository<Role,Long>{
    
}
