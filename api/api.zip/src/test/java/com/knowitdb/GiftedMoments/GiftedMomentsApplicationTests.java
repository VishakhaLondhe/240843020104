package com.knowitdb.GiftedMoments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiftedMomentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
