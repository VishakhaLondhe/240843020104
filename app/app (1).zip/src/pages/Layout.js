import React from "react";
import NavigationBar from "../Component/NavigationBar";
import { Outlet } from "react-router-dom";

export default function Layout() {
  return (
    <>
      <NavigationBar />

      <div>
        <Outlet />
      </div>
    </>
  );
}
