import React from "react";
import NavigationBar from "../Component/NavigationBar";

export default function Home() {
  return (
    <>
      <div>Home</div>
      <div>Page</div>
    </>
  );
}
