/*// import React, { useReducer } from 'react';

// // Define the initial state
// const initialState = {
//     uname: '',
//     email: '',
//     password: '',
//     contact: '',
//     address: '',
//     role: 2, // Set the default role to 2
//     gstNo: '',
//     regNo: '',
//     shopname: '',
//     message: '',
// };

// // Define the reducer function
// const formReducer = (state, action) => {
//     switch (action.type) {
//         case 'SET_FIELD':
//             return {
//                 ...state,
//                 [action.field]: action.value,
//             };
//         case 'SET_MESSAGE':
//             return {
//                 ...state,
//                 message: action.message,
//             };
//         default:
//             return state;
//     }
// };

// const SellerForm = () => {
//     // Initialize the state using useReducer
//     const [state, dispatch] = useReducer(formReducer, initialState);

//     // Handle input changes for fields
//     const handleInputChange = (e) => {
//         const { name, value } = e.target;
//         dispatch({ type: 'SET_FIELD', field: name, value });
//     };

//     // Handle form submission for seller creation
//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         const sellerData = {
//             uname: state.uname,
//             email: state.email,
//             password: state.password,
//             contact: state.contact,
//             address: state.address,
//             role: state.role, // This will always be 2
//             gstNo: state.gstNo,
//             regNo: state.regNo,
//             shopname: state.shopname,
//         };

//         try {
//             const response = await fetch('http://localhost:8080/sellers/create', {
//                 method: 'POST',
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//                 body: JSON.stringify(sellerData),
//             });

//             if (response.ok) {
//                 const successMessage = await response.text();
//                 dispatch({ type: 'SET_MESSAGE', message: successMessage });
//             } else {
//                 const errorMessage = await response.text();
//                 dispatch({ type: 'SET_MESSAGE', message: `Registration failed: ${errorMessage}` });
//             }
//         } catch (error) {
//             dispatch({ type: 'SET_MESSAGE', message: `An error occurred: ${error.message}` });
//         }
//     };

//     return (
//         <div>
//             <h2>Create Seller</h2>

//             <form onSubmit={handleSubmit}>
//                 <div>
//                     <label htmlFor="uname">Username</label>
//                     <input
//                         type="text"
//                         id="uname"
//                         name="uname"
//                         value={state.uname}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="email">Email</label>
//                     <input
//                         type="email"
//                         id="email"
//                         name="email"
//                         value={state.email}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="password">Password</label>
//                     <input
//                         type="password"
//                         id="password"
//                         name="password"
//                         value={state.password}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="contact">Contact</label>
//                     <input
//                         type="text"
//                         id="contact"
//                         name="contact"
//                         value={state.contact}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="address">Address</label>
//                     <input
//                         type="text"
//                         id="address"
//                         name="address"
//                         value={state.address}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="role">Role ID</label>
//                     <input
//                         type="number"
//                         id="role"
//                         name="role"
//                         value={state.role} // This value is fixed to 2
//                         readOnly
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="gstNo">GST Number</label>
//                     <input
//                         type="text"
//                         id="gstNo"
//                         name="gstNo"
//                         value={state.gstNo}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="regNo">Registration Number</label>
//                     <input
//                         type="text"
//                         id="regNo"
//                         name="regNo"
//                         value={state.regNo}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <div>
//                     <label htmlFor="shopname">Shop Name</label>
//                     <input
//                         type="text"
//                         id="shopname"
//                         name="shopname"
//                         value={state.shopname}
//                         onChange={handleInputChange}
//                         required
//                     />
//                 </div>

//                 <button type="submit">Create Seller</button>
//             </form>

//             {state.message && <p>{state.message}</p>}
//         </div>
//     );
// };

*/













import React, { useReducer } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

// Define the initial state
const initialState = {
  uname: "",
  email: "",
  password: "",
  contact: "",
  address: "",
  role: 5, // Set the default role to 2
  gstNo: "",
  regNo: "",
  shopname: "",
  message: "",
};

// Define the reducer function
const formReducer = (state, action) => {
  switch (action.type) {
    case "SET_FIELD":
      return {
        ...state,
        [action.field]: action.value,
      };
    case "SET_MESSAGE":
      return {
        ...state,
        message: action.message,
      };
    default:
      return state;
  }
};

const SellerForm = () => {
  const [state, dispatch] = useReducer(formReducer, initialState);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    dispatch({ type: "SET_FIELD", field: name, value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const sellerData = {
      uname: state.uname,
      email: state.email,
      password: state.password,
      contact: state.contact,
      address: state.address,
      
      role: state.role, // This will always be 2
      gstNo: state.gstNo,
      regNo: state.regNo,
      shopname: state.shopname,
    };
    console.log(sellerData);

    try {
      const response = await fetch("http://localhost:8080/sellers/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(sellerData),
      });

      if (response.ok) {
        const successMessage = await response.text();
        dispatch({ type: "SET_MESSAGE", message: successMessage });
      } else {
        const errorMessage = await response.text();
        dispatch({
          type: "SET_MESSAGE",
          message: `Registration failed: ${errorMessage}`,
        });
      }
    } catch (error) {
      dispatch({
        type: "SET_MESSAGE",
        message: `An error occurred: ${error.message}`,
      });
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center  bg-light">
      <div className="card shadow-lg p-4" style={{ width: "600px" }}>
        <h2 className="text-center mb-4">Create Seller</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="uname" className="form-label">
              Username
            </label>
            <input
              type="text"
              id="uname"
              name="uname"
              className="form-control"
              value={state.uname}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              className="form-control"
              value={state.email}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              className="form-control"
              value={state.password}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="contact" className="form-label">
              Contact
            </label>
            <input
              type="text"
              id="contact"
              name="contact"
              className="form-control"
              value={state.contact}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="address" className="form-label">
              Address
            </label>
            <input
              type="text"
              id="address"
              name="address"
              className="form-control"
              value={state.address}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="gstNo" className="form-label">
              GST Number
            </label>
            <input
              type="text"
              id="gstNo"
              name="gstNo"
              className="form-control"
              value={state.gstNo}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="regNo" className="form-label">
              Registration Number
            </label>
            <input
              type="text"
              id="regNo"
              name="regNo"
              className="form-control"
              value={state.regNo}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="shopname" className="form-label">
              Shop Name
            </label>
            <input
              type="text"
              id="shopname"
              name="shopname"
              className="form-control"
              value={state.shopname}
              onChange={handleInputChange}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary w-100">
            Create Seller
          </button>
        </form>

        {state.message && (
          <p
            className={`mt-3 text-center ${
              state.message.includes("success")
                ? "text-success"
                : "text-danger"
            }`}
          >
            {state.message}
          </p>
        )}
      </div>
    </div>
  );
};

export default SellerForm;
