/*import React, { useState, useEffect } from 'react';

const LoginForm = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [isLoginSuccessful, setIsLoginSuccessful] = useState(false);

    // Handle email and password input changes
    const handleEmailChange = (e) => setEmail(e.target.value);
    const handlePasswordChange = (e) => setPassword(e.target.value);

    // Handle form submission for login
    const handleLogin = async (e) => {
        e.preventDefault();

        // Send POST request to login API
        try {
            const response = await fetch('http://localhost:8080/users/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    password: password,
                }),
            });

            if (response.ok) {a
                const roleName = await response.text();
                setMessage(`Login successful! Role: ${roleName}`);
                setIsLoginSuccessful(true);
            } else {
                setMessage('Invalid email or password');
                setIsLoginSuccessful(false);
            }
        } catch (error) {
            setMessage('An error occurred: ' + error.message);
            setIsLoginSuccessful(false);
        }
    };

    // Handle form submission for registration
    const handleRegister = async (e) => {
        e.preventDefault();

        // Send POST request to register API
        try {
            const response = await fetch('http://localhost:8080/users/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    password: password,
                }),
            });

            if (response.ok) {
                setMessage('Registration successful');
                setIsLoginSuccessful(true);
            } else {
                const errorMessage = await response.text();
                setMessage(`Registration failed: ${errorMessage}`);
                setIsLoginSuccessful(false);
            }
        } catch (error) {
            setMessage('An error occurred: ' + error.message);
            setIsLoginSuccessful(false);
        }
    };

    // You can use useEffect for side effects, e.g., to check if user is already logged in
    useEffect(() => {
        // Placeholder for side effects if needed
        // For example, you could check for a stored token here
    }, []);

    return (
        <div>
            <h2>{isLoginSuccessful ? 'Welcome back!' : 'Please Sign In or Register'}</h2>

            <form onSubmit={handleLogin}>
                <div>
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={handleEmailChange}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={handlePasswordChange}
                        required
                    />
                </div>

                <button type="submit">Sign In</button>
                <button onClick={handleRegister}>Sign Up</button>
            </form>

            {message && <p>{message}</p>}
        </div>
    );
};

export default LoginForm;*/












import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLoginSuccessful, setIsLoginSuccessful] = useState(false);

  const handleEmailChange = (e) => setEmail(e.target.value);
  const handlePasswordChange = (e) => setPassword(e.target.value);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8080/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      });

      if (response.ok) {
        const roleName = await response.text();
        setMessage(`Login successful! `);
        setIsLoginSuccessful(true);
      } else {
        setMessage("Invalid email or password");
        setIsLoginSuccessful(false);
      }
    } catch (error) {
      setMessage("An error occurred: " + error.message);
      setIsLoginSuccessful(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8080/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      });

      if (response.ok) {
        setMessage("Registration successful");
        setIsLoginSuccessful(true);
      } else {
        const errorMessage = await response.text();
        setMessage(`Registration failed: ${errorMessage}`);
        setIsLoginSuccessful(false);
      }
    } catch (error) {
      setMessage("An error occurred: " + error.message);
      setIsLoginSuccessful(false);
    }
  };

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(""), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100 bg-light"
    >
      <div className="card p-4 shadow-lg" style={{ width: "400px" }}>
        <h2 className="text-center mb-4">
          {isLoginSuccessful ? "Welcome back!" : "LOGIN"}
        </h2>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <input
              type="email"
              id="email"
              className="form-control"
              value={email}
              onChange={handleEmailChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="form-control"
              value={password}
              onChange={handlePasswordChange}
              required
            />
          </div>
          <div className="d-grid gap-2">
            <button type="submit" className="btn btn-primary">
              Sign In
            </button>
            <button
              type="button"
              onClick={handleRegister}
              className="btn btn-secondary"
            >
              Sign Up
            </button>
          </div>
        </form>
        {message && (
          <p
            className={`mt-3 text-center ${
              isLoginSuccessful ? "text-success" : "text-danger"
            }`}
          >
            {message}
          </p>
        )}
      </div>
    </div>
  );
};

export default LoginForm;






// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom"; // Assuming you're using React Router
// import "bootstrap/dist/css/bootstrap.min.css";

// const LoginForm = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [message, setMessage] = useState("");
//   const [isLoginSuccessful, setIsLoginSuccessful] = useState(false);

//   const navigate = useNavigate();

//   const handleEmailChange = (e) => setEmail(e.target.value);
//   const handlePasswordChange = (e) => setPassword(e.target.value);

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch("http://localhost:8080/users/login", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           email: email,
//           password: password,
//         }),
//       });

//       if (response.ok) {
//         const roleName = await response.text();
//         setMessage(`Login successful!`);
//         setIsLoginSuccessful(true);
//       } else {
//         setMessage("Invalid email or password");
//         setIsLoginSuccessful(false);
//       }
//     } catch (error) {
//       setMessage("An error occurred: " + error.message);
//       setIsLoginSuccessful(false);
//     }
//   };

//   const handleRegister = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch("http://localhost:8080/users/register", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           email: email,
//           password: password,
//         }),
//       });

//       if (response.ok) {
//         setMessage("Registration successful");
//         setIsLoginSuccessful(true);
//       } else {
//         const errorMessage = await response.text();
//         setMessage(`Registration failed: ${errorMessage}`);
//         setIsLoginSuccessful(false);
//       }
//     } catch (error) {
//       setMessage("An error occurred: " + error.message);
//       setIsLoginSuccessful(false);
//     }
//   };

//   useEffect(() => {
//     if (message) {
//       const timer = setTimeout(() => setMessage(""), 3000);
//       return () => clearTimeout(timer);
//     }
//   }, [message]);

//   return (
//     <div
//       className="d-flex justify-content-center align-items-center vh-100 bg-light"
//     >
//       <div className="card p-4 shadow-lg" style={{ width: "400px" }}>
//         <h2 className="text-center mb-4">
//           {isLoginSuccessful ? "Welcome back!" : "LOGIN"}
//         </h2>
//         <form onSubmit={handleLogin}>
//           <div className="mb-3">
//             <label htmlFor="email" className="form-label">
//               Email
//             </label>
//             <input
//               type="email"
//               id="email"
//               className="form-control"
//               value={email}
//               onChange={handleEmailChange}
//               required
//             />
//           </div>
//           <div className="mb-3">
//             <label htmlFor="password" className="form-label">
//               Password
//             </label>
//             <input
//               type="password"
//               id="password"
//               className="form-control"
//               value={password}
//               onChange={handlePasswordChange}
//               required
//             />
//           </div>
//           <div className="d-grid gap-2">
//             <button type="submit" className="btn btn-primary">
//               Sign In
//             </button>
//             <button
//               type="button"
//               onClick={handleRegister}
//               className="btn btn-secondary"
//             >
//               Sign Up
//             </button>
//           </div>
//         </form>
//         {message && (
//           <p
//             className={`mt-3 text-center ${
//               isLoginSuccessful ? "text-success" : "text-danger"
//             }`}
//           >
//             {message}
//           </p>
//         )}

//         {/* New user options */}
//         {!isLoginSuccessful && (
//           <div className="mt-4 text-center">
//             <p>If you are a new user:</p>
//             <div className="d-flex justify-content-around">
//               <button
//                 className="btn btn-outline-primary"
//                 onClick={() => navigate("/buyer-registration")}
//               >
//                 Buyer Registration
//               </button>
//               <button
//                 className="btn btn-outline-secondary"
//                 onClick={() => navigate("/seller-registration")}
//               >
//                 Seller Registration
//               </button>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LoginForm;
