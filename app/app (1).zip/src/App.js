
import './App.css';
import LoginForm from './Component/LoginCheck';
import SellerForm from './Component/SellerRegistraion';
import BuyerRegistration from './Component/BuyerRegistration';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Layout from './pages/Layout';

function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     {/* <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p> */}
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //     </a>
    //      {/* <LoginForm></LoginForm> */}
    //       <SellerForm></SellerForm> 
    //      {/* <BuyerRegistration></BuyerRegistration>  */}
    //   // </header>
    // </div>

    <BrowserRouter>
      <Routes>
      <Route path='/' element={<Layout />} >
        
          <Route index element={<Home />} />
          <Route path="seller-form" element={<SellerForm />} />
          <Route path="login-form" element={<LoginForm />} />
          <Route path="buyer-registration-form" element={<BuyerRegistration />} />
      </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
